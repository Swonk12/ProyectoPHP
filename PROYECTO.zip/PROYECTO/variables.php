<?php
    define('DB_CONN','mysql:host=localhost;port=3306;dbname=eduhacks');
    define('DB_USER','root');
    define('DB_PASS','');